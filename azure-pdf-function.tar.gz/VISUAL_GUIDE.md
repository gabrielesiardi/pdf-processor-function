# 🎨 Visual Deployment Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        YOUR APPLICATION                      │
│  (Web App, Mobile App, Desktop, API, Logic App, etc.)      │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ HTTP POST
                            │ { pdf_base64, prompt }
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      AZURE FUNCTION                          │
│                   (ProcessPDF Endpoint)                      │
├─────────────────────────────────────────────────────────────┤
│  1. Receives Request                                         │
│     └─> Validates: pdf_base64, prompt                      │
│                                                              │
│  2. Calls Mistral OCR                                       │
│     └─> Extracts text from ALL pages                       │
│     └─> Returns markdown content                            │
│                                                              │
│  3. Calls Mistral Chat                                      │
│     └─> Uses YOUR custom prompt                            │
│     └─> Structures data as JSON                            │
│                                                              │
│  4. Returns Response                                        │
│     └─> { status, data, metadata }                         │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ Immediate JSON response
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    YOUR APPLICATION                          │
│                (Receives structured data)                    │
└─────────────────────────────────────────────────────────────┘
```

## Deployment Flow

### Option 1: Automated Deployment (Recommended for Beginners)

```
┌──────────────┐
│   YOU RUN    │
│  ./deploy.sh │
└──────┬───────┘
       │
       ├─> Creates Resource Group
       ├─> Creates Storage Account
       ├─> Creates Function App
       ├─> Configures Environment Variables
       ├─> Deploys Code
       │
       ▼
┌──────────────┐
│   SUCCESS    │
│  Function URL│
│ & Key Shown  │
└──────────────┘
```

### Option 2: GitHub Actions (Recommended for Teams)

```
┌──────────────────┐
│  PUSH TO GITHUB  │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐     ┌─────────────────┐
│  GITHUB ACTIONS  │────>│ BUILD & TEST    │
│  Auto Triggered  │     └────────┬────────┘
└──────────────────┘              │
                                  ▼
                         ┌─────────────────┐
                         │ DEPLOY TO AZURE │
                         └────────┬────────┘
                                  │
                                  ▼
                         ┌─────────────────┐
                         │  FUNCTION LIVE  │
                         └─────────────────┘
```

### Option 3: Manual Deployment (For Full Control)

```
1. az login
   └─> Authenticate to Azure

2. az group create
   └─> Create resource group

3. az storage account create
   └─> Create storage account

4. az functionapp create
   └─> Create function app

5. az functionapp config appsettings set
   └─> Set MISTRAL_API_KEY & MISTRAL_BASE_URL

6. func azure functionapp publish
   └─> Deploy code

7. Get URL & Key
   └─> Test function
```

## Request/Response Flow

```
┌─────────────────────────────────────────────────────────────┐
│                          REQUEST                             │
├─────────────────────────────────────────────────────────────┤
│  POST /api/process-pdf?code=YOUR_KEY                        │
│                                                              │
│  Headers:                                                    │
│    Content-Type: application/json                           │
│                                                              │
│  Body:                                                       │
│  {                                                           │
│    "pdf_base64": "JVBERi0xLjQKJeLjz9MK...",               │
│    "prompt": "Extract invoice data including vendor,        │
│               date, total, and line items. Return JSON."    │
│  }                                                           │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ Processing Time: 3-6 seconds
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                          RESPONSE                            │
├─────────────────────────────────────────────────────────────┤
│  Status: 200 OK                                              │
│                                                              │
│  {                                                           │
│    "status": "success",                                      │
│    "data": {                                                 │
│      "vendor": "Acme Corporation",                           │
│      "invoice_date": "2025-01-15",                          │
│      "total_amount": 1250.00,                               │
│      "line_items": [                                         │
│        {                                                     │
│          "description": "Widget A",                          │
│          "quantity": 10,                                     │
│          "unit_price": 50.00,                               │
│          "line_total": 500.00                               │
│        },                                                    │
│        {                                                     │
│          "description": "Widget B",                          │
│          "quantity": 5,                                      │
│          "unit_price": 150.00,                              │
│          "line_total": 750.00                               │
│        }                                                     │
│      ]                                                       │
│    },                                                        │
│    "metadata": {                                            │
│      "characters_extracted": 1523,                          │
│      "processing_timestamp": "2025-11-05T10:30:00.000000"  │
│    }                                                         │
│  }                                                           │
└─────────────────────────────────────────────────────────────┘
```

## File Structure Visualization

```
azure-pdf-function/
│
├── 📘 Documentation (Start Here!)
│   ├── INDEX.md ........................... Main entry point
│   ├── START_HERE.md ..................... Step-by-step guide
│   ├── PROJECT_SUMMARY.md ................ Overview
│   ├── QUICKSTART.md ..................... Quick reference
│   ├── README.md ......................... Full docs
│   ├── CHANGES.md ........................ What changed
│   └── COMPARISON.md ..................... Before/After
│
├── ⚙️ Function Code
│   └── ProcessPDF/
│       ├── __init__.py ................... Main function (167 lines)
│       └── function.json ................. Function config
│
├── 🔧 Configuration
│   ├── host.json ......................... Function app settings
│   ├── requirements.txt .................. Dependencies (2)
│   └── local.settings.json ............... Local dev config
│
├── 🚀 Deployment
│   ├── deploy.sh ......................... Automated deployment
│   ├── push-to-github.sh ................. GitHub push helper
│   └── .github/workflows/deploy.yml ...... CI/CD pipeline
│
└── 🧪 Testing
    └── test_function.py .................. Testing utility
```

## Component Interactions

```
┌───────────────────────────────────────────────────────────┐
│                  MISTRAL DOCUMENT AI                       │
│                    (OCR Service)                           │
│  • Extracts text from PDF                                 │
│  • Handles multi-page documents                           │
│  • Returns markdown formatted text                        │
└─────────────────────┬─────────────────────────────────────┘
                      │
                      │ Markdown Text
                      │
                      ▼
┌───────────────────────────────────────────────────────────┐
│                  YOUR AZURE FUNCTION                       │
│  • Orchestrates the process                               │
│  • Handles HTTP requests                                  │
│  • Manages error handling                                 │
│  • Formats responses                                      │
└─────────────────────┬─────────────────────────────────────┘
                      │
                      │ Prompt + Text
                      │
                      ▼
┌───────────────────────────────────────────────────────────┐
│                  MISTRAL SMALL                            │
│                 (Chat Service)                            │
│  • Processes custom prompts                               │
│  • Structures data as JSON                                │
│  • Intelligent data extraction                            │
└───────────────────────────────────────────────────────────┘
```

## Cost Breakdown

```
┌─────────────────────────────────────────────────────┐
│           MONTHLY COSTS (1,000 requests)            │
├─────────────────────────────────────────────────────┤
│                                                      │
│  Azure Functions (Consumption)      $0.20           │
│  ├─ Execution time: ~5s avg                         │
│  └─ Memory: ~100MB                                  │
│                                                      │
│  Mistral OCR API                   $10-20           │
│  ├─ Per-page processing                             │
│  └─ Depends on PDF size                             │
│                                                      │
│  Mistral Chat API                   $5-10           │
│  ├─ Token-based pricing                             │
│  └─ Depends on prompt/response size                 │
│                                                      │
│  ═══════════════════════════════════════            │
│  TOTAL                            ~$15-30            │
│                                                      │
│  ❌ Removed: Blob Storage           -$2             │
│  ❌ Removed: Extra API calls        -$3             │
│                                                      │
└─────────────────────────────────────────────────────┘
```

## Performance Metrics

```
┌────────────────────────────────────────────────────┐
│              PERFORMANCE PROFILE                    │
├────────────────────────────────────────────────────┤
│                                                     │
│  Cold Start                                        │
│  ▓▓▓▓░░░░░░ 3-5 seconds                           │
│                                                     │
│  Warm Request                                      │
│  ▓▓▓░░░░░░░ 3-6 seconds                           │
│                                                     │
│  Network Latency                                   │
│  ▓░░░░░░░░░ 0.5-1 second                          │
│                                                     │
│  OCR Processing                                    │
│  ▓▓▓▓▓░░░░░ 2-3 seconds                           │
│                                                     │
│  Chat Processing                                   │
│  ▓▓░░░░░░░░ 1-2 seconds                           │
│                                                     │
│  ═══════════════════════════════════               │
│  Total Average: 3-6 seconds                        │
│                                                     │
└────────────────────────────────────────────────────┘
```

## Scaling Model

```
           │
    1000   │                    ┌───────────
    req/s  │                  ┌─┘
           │                ┌─┘
     100   │              ┌─┘    Auto-scaling
    req/s  │            ┌─┘      kicks in
           │          ┌─┘
      10   │        ┌─┘
    req/s  │      ┌─┘
           │    ┌─┘
       1   │  ┌─┘
    req/s  └──┴─────────────────────────>
               Time →

  • Starts with 1 instance
  • Auto-scales based on load
  • Max concurrency: Configurable
  • Scale-out time: ~30 seconds
```

## Success Path

```
┌──────────────┐
│ Prerequisites│
│   Checked    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Deployed   │
│   Function   │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│    Tested    │
│  with Sample │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Integrated  │
│  into App    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Monitoring & │
│  Production  │
└──────────────┘
```

## Troubleshooting Flow

```
         ERROR?
           │
           ├─> 401 Unauthorized
           │   └─> Check MISTRAL_API_KEY
           │
           ├─> 400 Bad Request
           │   └─> Check request format
           │
           ├─> 500 Server Error
           │   └─> Check function logs
           │
           ├─> Timeout
           │   └─> Increase timeout in host.json
           │
           └─> No pages found
               └─> Check PDF validity
```

---

## Next Steps

1. **Read** [INDEX.md](INDEX.md) for overview
2. **Follow** [START_HERE.md](START_HERE.md) for deployment
3. **Test** with test_function.py
4. **Monitor** in Azure Portal
5. **Integrate** into your application

**Ready?** Start with [INDEX.md](INDEX.md)! 🚀
